PluginLibrary for MyBB
A collection of useful functions used by other plugins.

https://github.com/frostschutz/PluginLibrary

Users:

  Upload inc/plugins/pluginlibrary.php to your inc/plugins/ folder.
  No other files are required and no further steps are necessary.

Developers:

  Please refer to PluginLibrary-Documentation.html and / or
  to the sample plugin inc/plugins/hello_pl.php for detailed information
  on how to use PluginLibrary with your own plugins.
