DVZ Shoutbox 2.3.4
by Tomasz 'Devilshakerz' Mlynski [devilshakerz.com]
Copyright (C) 2014-2021

========= LICENSE ===================================================
released under Creative Commons BY-NC-SA 4.0 license:
http://creativecommons.org/licenses/by-nc-sa/4.0/ */

========= INSTALLATION ==============================================
1. upload the package from "UPLOAD" to your MyBB root directory
2. add CSS from STYLES.txt to your board stylesheets (e.g. global.css)
3. add {$dvz_shoutbox} to your index template
4. install the plugin in the ACP
