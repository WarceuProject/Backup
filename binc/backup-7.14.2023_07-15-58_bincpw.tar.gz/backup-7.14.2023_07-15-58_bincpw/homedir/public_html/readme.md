# [Newpoints Awards](http://www.chack1172.altervista.org/Projects/MyBB-18/Newpoints-Awards.html)
Category: [MyBB 1.8](http://www.chack1172.altervista.org/Projects/MyBB-18/)
Author: [chack1172](http://en.chack1172.altervista.org)

Newpoints Awards is an extension of the plugin OUGC Awards. It allows users to buy some awards with newpoints.

You can choose which awards users can buy and set a reason which will be shown in the award list of the user.

### Requirements
- [Newpoints](https://community.mybb.com/mods.php?action=view&pid=94)
- [OUGC Awards](https://community.mybb.com/mods.php?action=view&pid=396)

### Installation
1. Upload contents of the folder Upload to your board directory
2. Go to `ACP > Newpoints > Install & Activate 'Newpoints Awards'`
