# [Newpoints Awards](http://www.chack1172.altervista.org/Progetti/MyBB-18/Newpoints-Awards.html)
Category: [MyBB 1.8](http://www.chack1172.altervista.org/Progetti/MyBB-18/)
Author: [chack1172](http://it.chack1172.altervista.org)

Newpoints Awards � un estensione del plugin OUGC Awards. Consente agli utente di comprare alcuni premi con newpoints.

Puoi scegliere quali premi gli utenti possono acquistare e impostare un motivo che verr� mostrato nella lista premi dell'utente.

### Requisiti
- [Newpoints](https://community.mybb.com/mods.php?action=view&pid=94)
- [OUGC Awards](https://community.mybb.com/mods.php?action=view&pid=396)

### Installazione
1. Carica il contenuto della cartella Upload nella cartella della tua board
2. Vai in `ACP > Newpoints > Installa e Attiva 'Newpoints Awards'`
