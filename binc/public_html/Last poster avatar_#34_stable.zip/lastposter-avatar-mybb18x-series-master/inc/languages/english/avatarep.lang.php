<?php
/**
*  Language English
*  Last Poster Avatar 3.0
*
*  Sitio Web: https://soportemybb.es
*  Autor: Whiteneo - neogeoman@gmail.com
*/
$l['avatarep_user_profile'] = "View Profile";
$l['avatarep_user_messages'] = "View Messages";
$l['avatarep_user_sendpm'] = "Send PM";
$l['avatarep_user_sendemail'] = "Send E-mail";
$l['avatarep_user_threads'] = "View Threads";
$l['avatarep_user_error'] = " Error ";
$l['avatarep_user_error_text'] = " You must login to see this content ";
$l['avatarep_user_alt'] = "{1}'s Avatar";
$l['avatarep_user_no_avatar'] = "No avatar";
$l['avatarep_retrieving'] = "Retrieving Data";
$l['avatarep_loading'] = "Loading...";