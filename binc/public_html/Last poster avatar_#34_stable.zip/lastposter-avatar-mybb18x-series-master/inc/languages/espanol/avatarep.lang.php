<?php
/**
*  Idioma Español
*  Lastposter avatar v 3.0
*
*  Sitio Web: https://soportemybb.es
*  Autor: Whiteneo - neogeoman@gmail.com
*/
$l['avatarep_user_profile'] = "Ver Perfil";
$l['avatarep_user_messages'] = "Ver Mensajes";
$l['avatarep_user_sendpm'] = "Enviar MP";
$l['avatarep_user_sendemail'] = "Enviar Correo";
$l['avatarep_user_threads'] = "Ver Temas";
$l['avatarep_user_error'] = " Error ";
$l['avatarep_user_error_text'] = " Debes iniciar sesión para ver este contenido ";
$l['avatarep_user_alt'] = "Avatar de {1}";
$l['avatarep_user_no_avatar'] = "Sin avatar";
$l['avatarep_retrieving'] = "Obteniendo Datos";
$l['avatarep_loading'] = "Cargando...";