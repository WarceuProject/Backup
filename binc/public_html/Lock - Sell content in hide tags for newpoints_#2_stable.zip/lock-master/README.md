# lock
Lock is a MyBB plugin for hiding content and selling it for your Newpoints currency.
