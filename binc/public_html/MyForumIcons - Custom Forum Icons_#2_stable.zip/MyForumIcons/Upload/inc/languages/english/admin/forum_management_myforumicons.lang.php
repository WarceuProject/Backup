<?php

/*
 *	MyTabs English Language Pack
 *
 *	Created by Ethan DeLong
 *
 *	Like Pokemon? Check out http://www.pokemonforum.org
 *
 */
 
$l['myforumicons'] = "MyForumIcons";
$l['myforumicons_desc'] = "Settings for MyForumIcons.";

$l['forum_icons'] = "Custom Forum Icon";
$l['forum_icons_desc'] = "The path to the custom icon to use for this forum. If you want to use different icons for different themes, please use <strong>{theme}</strong> to represent the image directory of each theme.";

?>