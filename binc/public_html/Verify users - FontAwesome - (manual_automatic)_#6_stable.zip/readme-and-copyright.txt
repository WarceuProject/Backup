***** English *****

1) To verify users edit a user and switch to the tab "Account settings". Below you can set a checkbox.

2) Normally, the plugin automatically inserts the variable into the postbit template to display the icon. If this doesn't work for you (maybe because you have your own individual template/theme), 
you can add the following variable to the "postbit" template: {$post['icon_vf']}

3) Normally, the plugin automatically inserts the variable into the member_profile template to display the icon. If this doesn't work for you (maybe because you have your own individual template/theme), 
you can add the following variable to the "member_profile" template: {$icon_vf}

4) Normally, the plugin automatically edit the headerinclude template to activate/include fontawesome. If this doesn't work for you (maybe because you have your own individual template/theme), 
you can add the following to the "headerinclude" template: <link href="inc/plugins/css/all.min.css" rel="stylesheet">

***** Deutsch *****

1) Um Benutzer zu �berpr�fen, bearbeite einen Benutzer und wechsel zur Registerkarte "Account Einstellungen". Ganz unten kannst Du ein Kontrollk�stchen setzen.

2) Normalerweise f�gt das Plugin die Variable automatisch in das "postbit"-Template ein, um das Icon/ Image anzuzeigen. Wenn dies bei Dir nicht funktioniert sollte (vielleicht weil Du dein eigenes individuelles Template verwendest), kannst Du die folgende Variable dem "postbit"-Template hinzuf�gen: {$post['icon_vf']}

3) Normalerweise f�gt das Plugin die Variable automatisch in das "member_profile"-Template ein, um das Icon/ Image anzuzeigen. Wenn dies bei Dir nicht funktioniert sollte (vielleicht weil Du dein eigenes individuelles Template verwendest), kannst Du die folgende Variable dem "member_profile"-Template hinzuf�gen: {$icon_vf}

4) Normalerweise bearbeitet das Plugin automatisch die Headerinclude-Template, um Fonts zu aktivieren/inkludieren. Wenn dies bei Dir nicht funktioniert sollte (vielleicht weil Du dein eigenes individuelles Themplate verwendest), 
kannst Du dem "headerinclude"-Template folgendes hinzuf�gen: <link href="inc/plugins/css/all.min.css" rel="stylesheet">
