-- MyBB Database Backup
-- Generated: 09th April 2023 at 02:50
-- -------------------------------------

INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('1','main','newpoints_main_enabled','Is NewPoints enabled?','Set to no if you want to disable NewPoints.','yesno','1','1');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('2','main','newpoints_main_curname','Currency Name','Enter a name for the currency.','text','Credit','2');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('3','main','newpoints_main_curprefix','Currency Prefix','Enter what you want to display before the number of points.','text','¢','3');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('4','main','newpoints_main_cursuffix','Currency Suffix','Enter what you want to display after the number of points.','text','BINC','4');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('5','main','newpoints_main_decimal','Decimal Places','Number of decimals to be used.','text','2','5');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('6','main','newpoints_main_statsvisible','Statistics visible to users?','Set to no if you do not want users to view the statistics.','yesno','1','6');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('7','main','newpoints_main_donationsenabled','Donations enabled?','Set to no if you want to disable donations.','yesno','1','7');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('8','main','newpoints_main_donationspm','Send a PM on donate?','Do you want it to automatically send a new private message to a user receiving a donation?','yesno','1','8');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('9','main','newpoints_main_stats_lastdonations','Last donations','Number of last donations to show.','text','10','9');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('10','main','newpoints_main_stats_richestusers','Richest Users','Number of richest users to show.','text','500','9');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('11','income','newpoints_income_newpost','New Post','Amount of points received on new post.','text','3','1');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('12','income','newpoints_income_newthread','New Thread','Amount of points received on new thread.','text','5','2');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('13','income','newpoints_income_newpoll','New Poll','Amount of points received on new poll.','text','5','3');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('14','income','newpoints_income_perchar','Per Character','Amount of points received per character (in new thread and new post).','text','0.01','4');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('15','income','newpoints_income_minchar','Minimum Characters','Minimum characters required in order to receive the amount of points per character.','text','5','5');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('16','income','newpoints_income_newreg','New Registration','Amount of points received by the user when registering.','text','1','6');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('17','income','newpoints_income_pervote','Per Poll Vote','Amount of points received by the user who votes.','text','1','7');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('18','income','newpoints_income_perreply','Per Reply','Amount of points received by the author of the thread, when someone replies to it.','text','1','8');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('19','income','newpoints_income_pmsent','Per PM Sent','Amount of points received everytime a user sends a private message.','text','1','9');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('20','income','newpoints_income_perrate','Per Rate','Amount of points received everytime a user rates a thread.','text','0.05','9');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('21','income','newpoints_income_pageview','Per Page View','Amount of points received everytime a user views a page.','text','0','10');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('22','income','newpoints_income_visit','Per Visit','Amount of points received everytime a user visits the forum. (\"visits\" = new MyBB session (expires after 15 minutes))','text','0.1','11');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('23','income','newpoints_income_referral','Per Referral','Amount of points received everytime a user is referred. (the referred user is who receives the points)','text','5','12');
INSERT INTO mybb6a_newpoints_settings (sid,plugin,name,title,description,type,value,disporder) VALUES ('24','newpoints_hello','newpoints_hello_show','Show message','Set to yes if you want to show the hello message on every page.','yesno','0','1');
UPDATE `mybb6a_users` SET `newpoints` = '21.78' WHERE `uid` = '1';
UPDATE `mybb6a_users` SET `newpoints` = '6.00' WHERE `uid` = '2';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '3';
UPDATE `mybb6a_users` SET `newpoints` = '6.00' WHERE `uid` = '4';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '5';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '6';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '7';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '8';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '9';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '10';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '11';
UPDATE `mybb6a_users` SET `newpoints` = '6.00' WHERE `uid` = '12';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '13';
UPDATE `mybb6a_users` SET `newpoints` = '1.00' WHERE `uid` = '14';
UPDATE `mybb6a_datacache` SET `cache` = 'a:1:{s:6:"active";a:2:{s:16:"newpoints_awards";s:16:"newpoints_awards";s:15:"newpoints_hello";s:15:"newpoints_hello";}}' WHERE `title` = 'newpoints_plugins';
UPDATE `mybb6a_datacache` SET `cache` = 'a:0:{}' WHERE `title` = 'newpoints_rules';
UPDATE `mybb6a_datacache` SET `cache` = 'a:24:{s:22:"newpoints_main_curname";s:6:"Credit";s:24:"newpoints_main_curprefix";s:2:"¢";s:24:"newpoints_main_cursuffix";s:4:"BINC";s:22:"newpoints_main_decimal";s:1:"2";s:31:"newpoints_main_donationsenabled";s:1:"1";s:22:"newpoints_main_enabled";s:1:"1";s:34:"newpoints_main_stats_lastdonations";s:2:"10";s:24:"newpoints_income_minchar";s:1:"5";s:24:"newpoints_income_newpoll";s:1:"5";s:24:"newpoints_income_newpost";s:1:"3";s:23:"newpoints_income_newreg";s:1:"1";s:26:"newpoints_income_newthread";s:1:"5";s:24:"newpoints_income_perchar";s:4:"0.01";s:25:"newpoints_income_pageview";s:1:"0";s:23:"newpoints_income_pmsent";s:1:"1";s:24:"newpoints_income_pervote";s:1:"1";s:24:"newpoints_income_perrate";s:4:"0.05";s:25:"newpoints_income_referral";s:1:"5";s:25:"newpoints_income_perreply";s:1:"1";s:22:"newpoints_income_visit";s:3:"0.1";s:33:"newpoints_main_stats_richestusers";s:3:"500";s:26:"newpoints_main_donationspm";s:1:"1";s:20:"newpoints_hello_show";s:1:"0";s:27:"newpoints_main_statsvisible";s:1:"1";}' WHERE `title` = 'newpoints_settings';
