<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['nav_announcements'] = "Forum Announcement";
$l['announcements'] = "Announcement";
$l['forum_announcement'] = "Forum Announcement: {1}";
$l['error_invalidannouncement'] = "The announcement specified is invalid.";

$l['announcement_edit'] = "Edit this announcement";
$l['announcement_qdelete'] = "Delete this announcement";
$l['announcement_quickdelete_confirm'] = "Are you sure you want to delete this announcement?";

