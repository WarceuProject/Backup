<?php
$link = mysqli_connect("localhost","nexoxfts_nexouser","6}gapy6n9~cF","nexoxfts_nexodb");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to Database: " . mysqli_connect_error();
  }
?>