<?php
session_start(); 
include "conn.php";
include "config.php";

?>
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from tradecoins.pro/?a=faq by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 Aug 2021 20:10:16 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" width="1200">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>NEXO-INVESTFX</title>
    
    

    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/odometer.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/jquery.animatedheadline.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>




    <div class="overlay"></div>
    <a href="#" class="scrollToTop">
        <i class="fal fa-long-arrow-alt-up"></i>
    </a>


    <header class="header-section">
        <div class="container">
            <div class="header-wrapper">
                <div class="logo">
                    <a href="index.php">
                        <img src="assets/img/logo/logo.png" alt="logo">
                    </a>
                </div>
                <ul class="menu">
                    <li>
                        <a href="index.php">Home</a>
                       </li>
                    <li>
                        <a href="about.php">About us</a>
                    </li>
                    <li>
                        <a href="rules.php">Rules</a>
                    </li>
                    <li>
                        <a href="faq.php">Faq's</a>
                    </li>
                    
                    <li>
                        <a href="contact.php">contact</a>
                    </li>
                    <?php
                                                 if(isset($_SESSION['email'])){ 
                                                     ?>
                                        <li class="header-button pr-0">
                        <a href="account/">account</a>
                    </li>
                    
                    <li class="header-button pr-0">
                        <a href="account/logout.php">logout</a>
                    </li>
                    <?php }else{ ?>

                        <li class="header-button pr-0">
                        <a href="login.php">Login</a>
                    </li>
                    
                    <li class="header-button pr-0">
                        <a href="register.php">signup</a>
                    </li>

                        <?php } ?>
                                    </ul>
       
            </div>
        </div>
    </header>

<section class="main-page-header speaker-banner" style="background: url('assets/img/banner-1.jpg');">
    <div class="container">
        <div class="speaker-banner-content">
            <h2 class="title">faq</h2>
            <ul class="breadcrumb">
                <li>
                    <a href="index.php">
                        Home
                    </a>
                </li>
                <li>
                    faq
                </li>
            </ul>
        </div>
    </div>
</section>
<section class="faq-section padding-top">
    <div class="container">
        <div class="section-header-3">
            <span class="cate">FAQS?</span>
            <h2 class="title">Frequently Asked Questions</h2>
        </div>
        <div class="faq-area padding-bottom">
            <div class="faq-wrapper">
                <div class="faq-item open">
                    <div class="faq-title">
                        <h6 class="title">What is NEXO-INVESTFX?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content" style="display: block;">
                        <p>
                        NEXO-INVESTFX is a forex trading technology company. We invest significant time and resources to ensure our traders have the best tools for the job. That means constantly evolving and innovating to increase productivity and performance for both merchants and developers. By hiring the best talent and providing an environment in which knowledge and skills can thrive, we bring value to market.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">Do I need to consider any fees or commissions when withdrawing funds?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            The company does not charge any fees or charges for the withdrawal of funds. All you need to do is to keep in mind the actual exchange rate that will be used to convert your invested amount and the fees that electronic payment systems may charge to facilitate transactions.

                        </p>
                    </div>
                </div>
                <div class="faq-item active">
                    <div class="faq-title">
                        <h6 class="title">can i withdraw my deposit?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content" style="display: none;">
                        <p>
                            Of course, your deposit will be returned after 5 days of contract expires.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">Can I put the company on my blog or monitoring?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            Yes, You can put the company on your blog or monitoring.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">What trading experience do your traders have?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            This is a corporation and trading is not our core business. But our traders have a successful experience of working on the largest global platforms.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">Which electronic payment systems are available for the investment process?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            Investments can be made through the following electronic payment systems: Perfect Money, Bitcoin, Ethereum. Litecoin, Dogecoin

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">How can I start earning money by inviting partners to the company?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            To start inviting partners, Create an account here, Share link with your friends and generate traffic to our website, Get Rewarded and Earn Money from our website.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">For what minimum amount can I purchase a financial package?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            The minimum deposit with the company is  10 USD.
                            
                            </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">What is the minimum amount to make a withdrawal on my account?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            The minimum withdraw is 1 USD Perfect Money, 25 USD for Bitcoin and Ethereum, 10 USD for Litecoin and Dogecoin.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">When I make a withdrawal, how fast will it be processed? </h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            Withdrawals are processed instant.
                        
                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">Can I be sure that my funds are safe?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            We have created a special department that distributes risks and selects the best insurance offers from around the world.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">Does the company operate legally?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            The company is registered in the United State and has a registration certificate.

                        </p>
                    </div>
                </div>
                <div class="faq-item">
                    <div class="faq-title">
                        <h6 class="title">Can I create several personal accounts?</h6>
                        <span class="right-icon"></span>
                    </div>
                    <div class="faq-content">
                        <p>
                            You cannot register more than one active accounts. If you violate the rules, your account will be automatically suspended
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="footer-section pt-5">
    <div class="footer-section-box">
<div class="container">
<div class="footer-middle">
<div class="row">
<div class="col-sm-3">
<a href="index.php"><img src="assets/img/logo/logo.png" alt="Logo" width=170></a>
</div>
<div class="col-sm-6">
<img src="assets/img/pay2/18.png" alt="">
<img src="assets/img/pay2/48.png" alt="">
<img src="assets/img/pay2/68.png" alt="">
<img src="assets/img/pay2/69.png" alt="">
<img src="assets/img/pay2/79.png" alt="">

</div>

<div class="col-sm-3">

<p class="footer-text">2nd Floor College House, 17 King Edwards Road, Ruislip, London, United Kingdom, HA4 7AE </p>


</div>
</div>
</div>
 </div>
 </div>
        <div class="container">
            <div class="footer-bottom">
                <div class="footer-bottom-area">
                    <div class="left">
                        <p> ©2023 All Rights Reserved By <a href="#">NEXO-INVESTFX</a></p>
                    </div>
                    <ul class="links">
                      
                        <li>
                            <a href="rules.php">Privacy Policy</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>


    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/heandline.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/magnific-popup.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/odometer.min.js"></script>
    <script src="assets/js/viewport.jquery.js"></script>
    <script src="assets/js/nice-select.js"></script>
    <script src="assets/js/main.js"></script>
<script src="http://code.jivosite.com/widget/P4kBF9b3XY" async></script> </body>


<!-- Mirrored from tradecoins.pro/?a=faq by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 Aug 2021 20:10:16 GMT -->
</html>

