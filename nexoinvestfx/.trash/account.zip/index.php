<?php
session_start(); 
include "conn.php";
include "config.php";


$total_sum1 = 0;

$sql= "SELECT * FROM users";
$result = mysqli_query($link,$sql);
$numrow = mysqli_num_rows($result);

$sql2= "SELECT * FROM users WHERE session = '1'";
$result2 = mysqli_query($link,$sql2);
$numrow2 = mysqli_num_rows($result2);

$sql22= "SELECT * FROM admin ";
$result23 = mysqli_query($link,$sql22);
$numrow121 = mysqli_fetch_assoc($result23);
$total_whatsapp = $numrow121['telegram'];


$sql1= "SELECT SUM(usd) as total_sum FROM btc WHERE type = 'Withdrawal'";
$result1 = mysqli_query($link,$sql1);
$numrow1 = mysqli_fetch_assoc($result1);
if($numrow1['total_sum']){
    $total_sum = $numrow1['total_sum'];
}else{
    $total_sum = 0;
}


$sql11= "SELECT SUM(usd) as total_value FROM btc WHERE type = 'Deposit'";
$result11 = mysqli_query($link,$sql11);
$numrow11 = mysqli_fetch_assoc($result11);
if($numrow11['total_value']){
    $total_sum1 = $numrow11['total_value'];
}else{
    $total_sum1 = 0;
}
?>
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from tradecoins.pro/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 Aug 2021 20:09:48 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" width="1200">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>NEXO-INVESTFX</title>
    
    

    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/odometer.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/jquery.animatedheadline.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>




    <div class="overlay"></div>
    <a href="#" class="scrollToTop">
        <i class="fal fa-long-arrow-alt-up"></i>
    </a>


    <header class="header-section">
        <div class="container">
            <div class="header-wrapper">
                <div class="logo">
                    <a href="index.php">
                        <img src="assets/img/logo/logo.png" alt="logo">
                    </a>
                </div>
                <ul class="menu">
                <a href="<?php echo $total_whatsapp;?>">
                        <img src="images/tg.png" alt="TG group">
                    </a>
                    </li>
                    <li>
                        <a href="index.php">Home</a>
                       </li>
                    <li>
                        <a href="about.php">About us</a>
                    </li>
                    <li>
                        <a href="rules.php">Rules</a>
                    </li>
                    <li>
                        <a href="faq.php">Faq</a>
                    </li>
                    
                    <li>
                        <a href="contact.php">contact</a>
                    </li>
                    <?php
                                                 if(isset($_SESSION['email'])){ 
                                                     ?>
                                        <li class="header-button pr-0">
                        <a href="account/">account</a>
                    </li>
                    
                    <li class="header-button pr-0">
                        <a href="account/logout.php">logout</a>
                    </li>
                    <?php }else{ ?>

                        <li class="header-button pr-0">
                        <a href="login.php">Login</a>
                    </li>
                    
                    <li class="header-button pr-0">
                        <a href="register.php">signup</a>
                    </li>

                        <?php } ?>
                                    </ul>
       
            </div>
        </div>
    </header>


    <section class="banner-section">
        <div class="banner-bg bg-fixed" style="background:url('assets/img/banner-1.jpg')"></div>
        <div class="container">
            <div class="banner-content">
                <div class="row">
                    <div class="col-sm-6">
                        <h1 class="title  cd-headline clip"><span class="d-block">YOU ARE INVESTING IN THE FUTURE!  Enjoy Earnings up to 225%</span>
                </h1>
                <p>Non-stop profit generating machine. Safe, very quick payment.</p>
                <a href="register.php" class="custom-button mt-5">Get Started</a>
                    </div>
                    <div class="col-sm-6">
                        <div style="position: absolute; top: -80px;">
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    
<section id="plan" class="pricing">
<div class="container">
<div class="row">
<div class="col-sm-3">
<div class="pricing-single">
<div class="pricing-header">
<div class="pricing-thumb">
<i class="fal fa-globe"></i>
</div>
<div class="pricing-title">
 STARTER</h2>
<h2>5% DAILY</h2>
<h5>FOR 2 DAYS</h5>
</div>
</div>
<div class="pricing-content">
<ul class="pricing-list">
<li><i class="fal fa-check"></i>$500 - $10,000</li>
<li><i class="fal fa-check"></i> 5% DAILY PROFIT </li>
</ul>
<button class="pricing-btn">Deposit</button>
</div>
</div>
</div>
<div class="col-sm-3">
<div class="pricing-single">
<div class="pricing-header">
<div class="pricing-thumb">
<i class="fal fa-globe"></i>
</div>
<div class="pricing-title">
 SILVER</h2>
<h2>10% DAILY</h2>
<h5>FOR 5 DAYS</h5>
</div>
</div>
<div class="pricing-content">
<ul class="pricing-list">
<li><i class="fal fa-check"></i> $10,000 - $50,000</li>
<li><i class="fal fa-check"></i> 10% DAILY PROFIT</li>
</ul>
<button class="pricing-btn">Deposit</button>
</div>
</div>
</div>
<div class="col-sm-3">
<div class="pricing-single">
<div class="pricing-header">
<div class="pricing-thumb">
<i class="fal fa-globe"></i>
</div>
<div class="pricing-title">
 DIAMOND</h2>
<h2>15% DAILY</h2>
<h5>FOR 7 DAYS</h5>
</div>
</div>
<div class="pricing-content">
<ul class="pricing-list">
<li><i class="fal fa-check"></i> $50,000 - $500,000</li>
<li><i class="fal fa-check"></i> 15% DAILY PROFIT</li>
</ul>
<button class="pricing-btn">Deposit</button>
</div>
</div>
</div>
<div class="col-sm-3">
<div class="pricing-single">
<div class="pricing-header">
<div class="pricing-thumb">
<i class="fal fa-globe"></i>
</div>
<div class="pricing-title">
 GOLD</h2>
<h2>25% DAILY</h2>
<h5>FOR 10 DAYS</h5>
</div>
</div>
<div class="pricing-content">
<ul class="pricing-list">
<li><i class="fal fa-check"></i> $500,000 - $50,000,000</li>
<li><i class="fal fa-check"></i> 25% DAILY PROFIT</li>
</ul>
<button class="pricing-btn">Deposit</button>
</div>
</div>
</div>

</div>
</div>
</section>


<section class="about-counter-section ">
<div class="container">

    
    
<!--<section id="aboutus" class="about-section padding-top padding-bottom">
<div class="container">
<div class="row justify-content-between">
<div class="col-sm-6">
<div class="event-about-content">
<div class="section-header-3 left-style m-0">
<span class="cate">About Us </span>
<h2 class="title">Know More About us</h2>
<p>
NEXO-INVESTFX is a forex trading technology company. We invest significant time and resources to ensure our traders have the best tools for the job. That means constantly evolving and innovating to increase productivity and performance for both merchants and developers. By hiring the best talent and providing an environment in which knowledge and skills can thrive, we bring value to market.
</p>
<a href="about.php" class="custom-button">Read more</a>
</div>
</div>
</div>
<div class="col-sm-5 d-none d-lg-block">
<div class="about-thumb">
<img src="assets/img/about2.png" alt="about">
 </div>
</div>
</div>
</div>
</section> -->

   <section class="search-ticket-section padding-top pt-lg-0">
        <div class="container">
            <div class="search-tab">
                <div class="row align-items-center mb--20">
                    <div class="col-lg-6 mb-20">
                        <div class="search-ticket-header">
                            <h6 class="category">Affiliate </h6>
                            <h3 class="title">Referal Commission </h3>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-20">
                        <ul class="tab-menu ticket-tab-menu">
                            <li class="active">
                                <span>5%</span>
                            </li>
                            <li class="active">
                                <span>2%</span>
                            </li>
                            <li class="active">
                                <span>1%</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section> 
    

<br/>

<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="about-counter">
<div class="counter-item">
<div class="counter-thumb">
<i class="fal fa-users"></i>
</div>
<div class="counter-content">
<h3 class="title"><?php echo $memadmin+$numrow; ?></h3>
</div>
<span class="d-block info">Investors</span>
</div>
<div class="counter-item">
<div class="counter-thumb">
<i class="fal fa-globe"></i>
</div>
<div class="counter-content">
<h3 class="title"><?php 
$current= date("Y-m-d");

$Date2 = date("2021-09-10");
$diff = abs(strtotime($current) - strtotime($Date2));

$days=floor($diff / (60*60*24));
echo $days+1;
?></h3>
</div>
<span class="d-block info">Days Online</span>
</div>
<div class="counter-item">
<div class="counter-thumb">
<i class="fal fa-city"></i>
</div>
<div class="counter-content">
<h3 class="title">$<?php echo number_format($depadmin+$total_sum1); ?></h3>
</div>
<span class="d-block info">Total Deposit</span>
</div>
<div class="counter-item">
<div class="counter-thumb">
<i class="fal fa-wallet"></i>
</div>
<div class="counter-content">
<h3 class="title">$<?php echo number_format($wthadmin+$total_sum); ?></h3>
</div>
<span class="d-block info">Total Withdraw</span>
</div>
</div>
</div>
</div>


</div>
</section>

    



<style>
    .table {
        border: 1px solid #31d7a9;
    }
    
    .table td {
        border-top: 1px solid #31d7a9;
    }
</style>





<footer class="footer-section pt-5">
    <div class="footer-section-box">
<div class="container">
<div class="footer-middle">
<div class="row">
<div class="col-sm-3">
<a href="index.php"><img src="assets/img/logo/logo.png" alt="Logo" width=170></a>
</div>
<div class="col-sm-6">
<img src="assets/img/pay2/18.png" alt="">
<img src="assets/img/pay2/48.png" alt="">
<img src="assets/img/pay2/68.png" alt="">
<img src="assets/img/pay2/69.png" alt="">
<img src="assets/img/pay2/79.png" alt="">

</div>
	<br />



      <p class="text-center"> Profit from Market Ups & Downs </p>

    </div>




          <!-- ============================================================================================================================ -->

      <div class="tradingview-widget-container__widget"></div>

            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js" async>

            {

            "width": "100%",

            "height": "400",

            "colorTheme": "dark",

            "currencies": [

              "EUR",

              "USD",

              "JPY",

              "GBP",

              "CHF",

              "AUD",

              "CAD",

              "NZD",

              "CNY"

            ],

            "locale": "en"

          }

            </script>

          </div>

          <!-- TradingView Widget END -->



      <!-- ============================================================================================================================ -->





      <!-- ============================================================================================================================ -->




<div class="col-sm-3">

<p class="footer-text">2006 Elmwood Ave, Sharon Hill, PA 19079, United States </p>


</div>
</div>
</div>
 </div>
 </div>
        <div class="container">
            <div class="footer-bottom">
                <div class="footer-bottom-area">
                    <div class="left">
                        <p> ©2023 NEXO-INVEST FX| All right reserved <a href="#">NEXO-INVESTFX</a></p>
                    </div>
                    <ul class="links">
                     
                        <li>
                            <a href="rules.php">Privacy Policy</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>


    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/heandline.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/magnific-popup.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/odometer.min.js"></script>
    <script src="assets/js/viewport.jquery.js"></script>
    <script src="assets/js/nice-select.js"></script>
    <script src="assets/js/main.js"></script>
 </body>


<!-- Mirrored from tradecoins.pro/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 13 Aug 2021 20:10:02 GMT -->
</html>
