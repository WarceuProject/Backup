<?php

echo "<script>

 alert('Payment Terminated!');
 window.location.href = 'deposit.php';
</script>";
?>


    
