<?php
$link = mysqli_connect("localhost","id20690708_btc","Z\uok0oYx]{2/N]Q","id20690708_nexo");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to Database: " . mysqli_connect_error();
  }
?>